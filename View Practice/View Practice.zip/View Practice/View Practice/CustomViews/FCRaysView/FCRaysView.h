//
//  FCRaysView.h
//  View Practice
//
//  Created by Isaac Greenbride on 8/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FCGradientStyle.h"
#define SUBDIVISIONS 16

@interface FCRaysView : UIView
{
    
}
@property FCGradientStyle *style1;
@property FCGradientStyle *style2;
@end
