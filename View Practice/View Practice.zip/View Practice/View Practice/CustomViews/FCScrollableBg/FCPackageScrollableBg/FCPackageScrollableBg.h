//
//  FCPackageScrollableBg.h
//  View Practice
//
//  Created by Isaac Greenbride on 8/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FCScrollableBg.h"

@interface FCPackageScrollableBg : FCScrollableBg
@property (assign) int jewelColor;
@end
