//
//  FCDecalScrollableBg.h
//  View Practice
//
//  Created by Isaac Greenbride on 8/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FCScrollableBg.h"

@interface FCDecalScrollableBg : FCScrollableBg
{
    int jewelColor;
}
@property (assign) int jewelColor;
@end
