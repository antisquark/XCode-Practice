//
//  FCInviteNewBg.h
//  View Practice
//
//  Created by Isaac Greenbride on 8/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TwoLevelView.h"

@interface FCInviteNewBg : TwoLevelView

- (id) initWithSize:(CGSize)myOrigin;
@end
