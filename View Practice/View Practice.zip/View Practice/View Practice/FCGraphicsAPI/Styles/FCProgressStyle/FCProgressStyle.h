//
//  FCProgressStyle.h
//  View Practice
//
//  Created by Isaac Greenbride on 8/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FCShapeStyle.h"


@interface FCProgressStyle : NSObject
{
    
}
@property (retain, nonatomic) FCShapeStyle *progressStyle;
@property (retain, nonatomic) FCShapeStyle *remainingStyle;
@end
