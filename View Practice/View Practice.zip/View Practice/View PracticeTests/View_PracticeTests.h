//
//  View_PracticeTests.h
//  View PracticeTests
//
//  Created by Isaac Greenbride on 8/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface View_PracticeTests : SenTestCase

@end
