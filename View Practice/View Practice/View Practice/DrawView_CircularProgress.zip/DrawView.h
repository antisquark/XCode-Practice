//
//  DrawView.h
//  Button Fun
//
//  Created by Isaac Greenbride on 8/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DrawView : UIView {

}
- (void)buttonPressed:(id)sender;

@end
